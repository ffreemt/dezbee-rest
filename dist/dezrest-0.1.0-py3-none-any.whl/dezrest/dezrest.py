"""Define dezrest."""
from logzero import logger


def dezrest():
    """Serve aligned results for ezbee."""
    logger.debug(" entry ")
