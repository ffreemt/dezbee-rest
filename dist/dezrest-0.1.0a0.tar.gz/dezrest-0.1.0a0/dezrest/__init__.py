"""Init."""
__version__ = "0.1.0a0"
from .dezrest import dezrest

__all__ = ("dezrest",)
